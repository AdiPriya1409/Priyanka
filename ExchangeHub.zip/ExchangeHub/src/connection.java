import java.sql.Connection;
import java.sql.DriverManager;
public class connection {
	private static Connection con;
	static String url = "jdbc:mysql://localhost:3306/exchangehub";
	static String username = "root";
	static String password = "root";
	public static Connection getConnection() {
     try {
    	 Class.forName("com.mysql.jdbc.Driver");
    	 con = DriverManager.getConnection(url,username,password);
    	 
     }	 
     catch(Exception e)
     { 
    	 e.printStackTrace();
     }
     return con ;

}
}