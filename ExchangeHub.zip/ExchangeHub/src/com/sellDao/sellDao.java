package com.sellDao;

import java.io.IOException;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.math.BigDecimal;

import com.connection.ConnectionProvider;



@WebServlet("/sellDao")

    public class sellDao{
	
	//String sql = "insert into sell() values (?,?,?,?,?,?,?,?,?)";
	//study stu = new study();
	
	
	public String insert(String brand,String published_year,String yea,String Ad_title,String Deceription,BigDecimal set_a_price,BigDecimal Mobile_no,InputStream img1,InputStream img2 )
	{
		Connection con = null; 
        String message = null;
		try {
			 con =ConnectionProvider.getConnection();
			System.out.println("I m in sell Dao");
            String sql = "INSERT INTO sell values (?,?,?,?,?,?,?,?,?)";

			 PreparedStatement st= con.prepareStatement(sql);
			    st.setString(1, brand);
	            st.setString(2, published_year);
	            st.setString(3, yea);
	            st.setString(4, Ad_title);
	            st.setString(5, Deceription);
	            st.setBigDecimal(6, set_a_price);
				st.setBigDecimal(7, Mobile_no);

		        //InputStream img1 = null;
		        //InputStream img2 = null;

				if (img1 != null) {
		               
	                st.setBlob(8,img1);
	            }
				if (img2 != null) {
		               
	                st.setBlob(9,img2);
	            }
				int a= st.executeUpdate();
				 if(a>0)
				 { 
					
					 System.out.println("table updated");
					 message = "File uploaded and saved into database";
		                return message;
				 }
				 else
					 System.out.println("Not updated");
				
			} catch (SQLException ex) {
	            message = "ERROR: " + ex.getMessage();

				ex.printStackTrace();
			}
		 return message;     


			
		}
	

		
	}
     
    

	