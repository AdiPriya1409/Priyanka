package com.fileupload;

import java.io.IOException;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;


/**
 * Servlet implementation class FileUploadDbServlet
 */
//@WebServlet("/FileUploadDbServlet")

@WebServlet("/uploadServlet")
@MultipartConfig(maxFileSize = 16177215)
public class FileUploadDbServlet extends HttpServlet {
	
		    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        //get values of text fields
	    	System.out.println("In DoPost");
	        String firstName = request.getParameter("firstName");
	        String lastName = request.getParameter("lastName");
	        InputStream inputStream = null; // input stream of the upload file
	        // obtains the upload file part in this multipart request
	        Part filePart = request.getPart("photo");
	        if (filePart != null) {
	            // prints out some information for debugging
	            System.out.println(filePart.getName());
	            System.out.println(filePart.getSize());
	            System.out.println(filePart.getContentType());

	            //obtains input stream of the upload file
	            //the InputStream will point to a stream that contains
	            //the contents of the file
	            inputStream = filePart.getInputStream();
	        }
            
	        FileUploadDao Dao=new FileUploadDao();
	        HttpSession session = request.getSession();
	        String message=Dao.insert(firstName,lastName,inputStream);
	        if(message!=null)
	        {
	        	session.setAttribute("imageUpload",message);
	        	response.sendRedirect("Upload.jsp");
	        }
	        else
	        {
	        	message="File is not uploaded and saved into database";
	        	session.setAttribute("imageNotUpload",message);
	        	response.sendRedirect("Upload.jsp");
	        }
	        
	 }
}
