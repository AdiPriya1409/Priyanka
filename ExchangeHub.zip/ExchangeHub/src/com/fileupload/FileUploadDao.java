package com.fileupload;

import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.connection.ConnectionProvider;
import com.login.Signup;

public class FileUploadDao {
	String sql = "insert into accounts_profile() values(?,?,?,?,?,?,?)";
	Signup sign = new Signup();
	int a;
	
	public String insert(String firstName,String lastName, InputStream inputStream)
	 {
		
		
		 Connection conn = null; // connection to the database
	        String message = null; // message will be sent back to client
	        try {
	            // connects to the database
	        	Connection con = ConnectionProvider.getConnection();
	        	System.out.println("I'm in SignupDao");
				
	            // constructs SQL statement
	            String sql = "INSERT INTO contacts (first_name, last_name, photo) values (?, ?, ?)";
	            //Using a PreparedStatement to save the file
	            PreparedStatement pstmtSave = con.prepareStatement(sql);
	            pstmtSave.setString(1, firstName);
	            pstmtSave.setString(2, lastName);

	            if (inputStream != null) {
	                //files are treated as BLOB objects in database
	                //here we're letting the JDBC driver
	                //create a blob object based on the
	                //input stream that contains the data of the file
	                pstmtSave.setBlob(3, inputStream);
	            }
	            //sends the statement to the database server
	            int row = pstmtSave.executeUpdate();
	            if (row > 0) {
	            	System.out.println("table updated");
	                message = "File uploaded and saved into database";
	                return message;
	            }
	        

	           /* String filepath = "C:\\Users\\WIN-10\\eclipse-workspace\\myServlet\\ExchangeHub\\WebContent\\img\\front.jpg";
	            //Obtaining the file from database
	            //Using a second statement
	            String sql1 = "SELECT photo FROM contacts WHERE first_name=? AND last_name=?";
	            PreparedStatement pstmtSelect = conn.prepareStatement(sql1);
	            pstmtSelect.setString(1, firstName);
	            pstmtSelect.setString(2, lastName);
	            ResultSet result = pstmtSelect.executeQuery();
	            if (result.next()) {
	                Blob blob = result.getBlob("photo");
	                InputStream inputStream1 = blob.getBinaryStream();
	                OutputStream outputStream = new FileOutputStream(filepath);
	                int bytesRead = -1;
	                byte[] buffer = new byte[BUFFER_SIZE];
	                while ((bytesRead = inputStream1.read(buffer)) != -1) {
	                    outputStream.write(buffer, 0, bytesRead);
	                }
	                inputStream1.close();
	                outputStream.close();
	                System.out.println("File saved");
	            }*/
	        } catch (SQLException ex) {
	            message = "ERROR: " + ex.getMessage();
	            ex.printStackTrace();
	        } 
	            // sets the message in request scope
	           // request.setAttribute("message", message);

	            // forwards to the message page
	            //getServletContext().getRequestDispatcher("/Message.jsp").include(request, response);
	        

		  return message;
	 }
}
