package com.fileupload;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.ConnectionProvider;

/**
 * Servlet implementation class getImage
 */
@WebServlet("/getImage")
public class getImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Connection  con = ConnectionProvider.getConnection();
			PreparedStatement st=con.prepareStatement("select * from sell");  
			//st.setInt(1, i);
		    ResultSet rs=st.executeQuery();
		    HttpSession session = request.getSession();
		    List<byte[]> list = new ArrayList<byte[]>() ;
		    int c=0;
		    String query = "SELECT COUNT() FROM sell";
		    PreparedStatement st1=con.prepareStatement("select count( *) from sell");
		    ResultSet rs1=st.executeQuery();
		    int a=rs1.getInt(1);
		    System.out.println("no. of rows"+a);
		    while(rs.next())
		    {
		    	Blob blob = rs.getBlob("img1");
		    	byte byteArray[] = blob.getBytes(1,(int)blob.length());
		    	list.add(byteArray);
		    	/*request.setAttribute("list", list);
		    	session.setAttribute("list", list);
		    	response.sendRedirect("index.jsp");
		    	//response.setContentType("image/gif");*/
		    	//OutputStream os = response.getOutputStream();
		    	//
		    	//os.flush();
		    	//os.close();
		    	c++;
		    	rs.next();
		    }
		    System.out.println(c);
		    System.out.println(list.size());
		    
		    OutputStream os = response.getOutputStream();
		    for(int i=0;i<list.size();i++)
		    {
		    	os.write(list.get(i));
		    }
		    os.flush();
	    	os.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
