package com.freeDao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Free.Free;
import com.connection.ConnectionProvider;

/**
 * Servlet implementation class FreeDao
 */
@WebServlet("/FreeDao")

public class FreeDao{
	Free f =new Free();
	
	public String insert(String Course,String Branch,String Semester,String Subject,String Topic,InputStream Uplode)
	{
		Connection con = null; 
        String message = null;
        try {
			 con =ConnectionProvider.getConnection();
			System.out.println("I m in Free Dao");
           String sql = "INSERT INTO Free(Course,Branch,Semester,Subject,Topic,Uplode) values (?,?,?,?,?,?)";
           
           
           
			 PreparedStatement st= con.prepareStatement(sql);
			    st.setString(1, Course);
			    st.setString(2,Branch);
			    st.setString(3,Semester);
			   st.setString(4, Subject);
	            st.setString(5, Topic);
	            
				

				if (Uplode != null) {
		               
	                st.setBlob(6,Uplode);
	            }
			
				
				int a= st.executeUpdate();
				 if(a>0)
					 {
					 System.out.println("table updated");
					 message = "File uploaded and saved into database";
		             return message;
					}
				 else
					 System.out.println("Not updated");
				
			} catch (SQLException ex) {
	            message = "ERROR: " + ex.getMessage();

				ex.printStackTrace();
			}
		 return message;     

	}
	
	
	
	
	
	public ResultSet getItem( )
	{
		ResultSet rs1=null;
		try {
			String getItem="select * from Free";
			Connection con = ConnectionProvider.getConnection();
			PreparedStatement st= con.prepareStatement(getItem);
		
			rs1 = st.executeQuery();
			
		
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return rs1;
		 
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}