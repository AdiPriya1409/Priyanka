package com.getImage;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.getImageDao.ImageDao;
import com.getImageDao.ImageDto;

/**
 * Servlet implementation class ImageViewSearchController
 */
@WebServlet("/ImageViewSearchController")
public class ImageViewSearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ImageDao imageDao=null;
		imageDao = new ImageDao();
		//int imageList[];    //declaring array
		//imageList = new int[20];
		//imageDto = imageDao.getData();
		String choose = request.getParameter("search");
		List<ImageDto> list = imageDao.getData();
		System.out.println("I'm in image view controller");
		request.setAttribute("list", list);
		RequestDispatcher rd = request.getRequestDispatcher("test.jsp");
		rd.forward(request, response);
	}

}
