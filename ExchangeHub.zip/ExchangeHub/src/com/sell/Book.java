package com.sell;

import java.io.IOException;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.sellMDao.SellMDao;

@WebServlet("/Book")
@MultipartConfig(maxFileSize = 16177215)

public class Book extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String brand =request.getParameter("brand");
		String Reg =request.getParameter("Reg");

		//String Item =request.getParameter("Item");
		//int  Item =Integer.parseInt(request.getParameter("Item"));
		String choose =request.getParameter("choose");


		
		String published_year =request.getParameter("published_year");
		String yea =request.getParameter("yea");
		String Ad_title =request.getParameter("Ad_title");
		BigDecimal Mobile_no=new BigDecimal(request.getParameter("Mobile_no"));
		String set_a_price =request.getParameter("set_a_price");

		String Description =request.getParameter("Description");
		InputStream inputStream1 = null; 
		Part filePart = request.getPart("img1");
		if (filePart != null) {
            System.out.println(filePart.getName());
            System.out.println(filePart.getSize());
            System.out.println(filePart.getContentType());

            inputStream1 = filePart.getInputStream();
        }
		InputStream inputStream2 = null; 
		Part filePart1 = request.getPart("img2");
		if (filePart1 != null) {
            // prints out some information for debugging
            System.out.println(filePart1.getName());
            System.out.println(filePart1.getSize());
            System.out.println(filePart1.getContentType());

            inputStream2 = filePart1.getInputStream();
        }

		
		SellMDao Dao =new SellMDao();
		HttpSession session = request.getSession();
        String message=Dao.insert(brand,Reg,choose,published_year,yea,Ad_title,Mobile_no,set_a_price,Description, inputStream1,inputStream2);
        if(message!=null)
        {
        	session.setAttribute("imageUpload",message);
        	response.sendRedirect("StudyMaterial.jsp");
        }
        else
        {
        	message="File is not uploaded and saved into database";
        	session.setAttribute("imageNotUpload",message);
        	response.sendRedirect("StudyMaterial.jsp");
        }


	
	}

}
