package com.Free;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.freeDao.FreeDao;
import com.sellMDao.SellMDao;

/**
 * Servlet implementation class Free
 */
@WebServlet("/Free")
@MultipartConfig(maxFileSize = 15728640)
public class Free extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		
		String Course =request.getParameter("Course");
		String Branch =request.getParameter("Branch");

		String Semester =request.getParameter("Semester");


		
		String Subject =request.getParameter("Subject");
		String Topic =request.getParameter("Topic");
		
		InputStream inputStream1 = null;
		Part filePart = request.getPart("Uplode");
		if (filePart != null) {
            System.out.println(filePart.getName());
            System.out.println(filePart.getSize());
            System.out.println(filePart.getContentType());

            inputStream1 = filePart.getInputStream();
        }
		
		
		
		FreeDao Dao =new FreeDao();
		HttpSession session = request.getSession();
        String message=Dao.insert(Course,Branch,Semester,Subject,Topic,inputStream1);
        if(message!=null)
        {
        	session.setAttribute("FileUpload",message);
        	response.sendRedirect("FreeUplode.jsp");
        }
        else
        {
        	message="File is not uploaded and saved into database";
        	session.setAttribute("imageNotUpload",message);
        	response.sendRedirect("FreeUplode.jsp");
        }

		
		
		
		
		
		
		
		
		
	}
}
	