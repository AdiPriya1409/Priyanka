package com.getImageDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.connection.ConnectionProvider;

public class ImageDao {
private final String  sql="select * from sell";
private final String  getImageQuery="select * from sell where Item=?";
	Connection con=null;
	PreparedStatement st=null;
	ResultSet rs=null;
	//Connection con=ConnectionProvider.getConnection(); 
	
public List<ImageDto> getData()
{
	System.out.println("I'm in imageDao");
ImageDto imageDto = null;
List<ImageDto> imageList=new ArrayList<ImageDto>();
	//List<Integer> imageList =(List<Integer>) new ArrayList<Integer>();
	//int imageList[];    //declaring array
	//imageList = new int[20];
	try {
		con=ConnectionProvider.getConnection();
		st=con.prepareStatement(sql);
		rs = st.executeQuery();
		int i=0;
		while(rs.next())
		{
			imageDto=new ImageDto();
			imageDto.setId(rs.getInt("Item"));
			 //imageDto.add(rs.getInt("Item"));
			imageList.add(imageDto);
			System.out.println("id"+imageDto);
			 i++;
			//rs.next();
		}
		System.out.println(i);
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	
	System.out.println("no. of images "+imageList.size());
	return imageList;
}

public byte[] getImage(int id)
{
	byte[] image=null;
	try {
		con=ConnectionProvider.getConnection();
		st=con.prepareStatement(getImageQuery);
		st.setInt(1, id);
		rs= st.executeQuery();
		if(rs.next())
		{
			image = rs.getBytes("img1");
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return image;
}
}
