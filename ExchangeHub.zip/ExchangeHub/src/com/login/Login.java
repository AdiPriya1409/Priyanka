package com.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.login.Dao.LoginDao;

import com.connection.ConnectionProvider;
/**
 * Servlet implementation class Login
 */
@WebServlet("/Login") 
public class Login extends HttpServlet {
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname=request.getParameter("uname");
		String pass=request.getParameter("pass");
		//Connection con = ConnectionProvider.getConnection();
		
		LoginDao Dao = new LoginDao();
		String user=Dao.check(uname,pass);
		if(user!=null)
        {
			HttpSession session = request.getSession();
			
			session.setAttribute("username", user);
             response.sendRedirect("welcome.jsp");  	
        }
		else
		{
			String message = "Wrong registration number or password";
			HttpSession session = request.getSession();
			session.setAttribute("wrongcred", message);
			response.sendRedirect("index.jsp");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	

}
