package com.login.Dao;
import  com.connection.ConnectionProvider;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDao {
   
	
	//String url = "jdbc:mysql://localhost:3306/db";
	//String username = "root";
	//String password = "root";
	Connection con = ConnectionProvider.getConnection();
	 public String check(String uname,String pass)
	 {
		try {
			//Class.forName("com.mysql.jdbc.Driver");
			//Connection con = DriverManager.getConnection(url,username,password);
			String sql = "select * from accounts_profile where reg_no=? and password=?";
			PreparedStatement st= con.prepareStatement(sql);
			st.setString(1,uname);
			st.setString(2, pass);
			ResultSet rs = st.executeQuery();
			
			//System.out.println("reg_no"+ re);
			//System.out.println("reg_no"+ps );
			if(rs.next())
			{
				/*String re= rs.getString(1);
				String ps=rs.getString(6);
				System.out.println("reg_no"+ re);
				System.out.println("reg_no"+ ps);*/
				return rs.getString(2);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		 
	 }
	 public String getUsername(String reg) {
		 String user="";
	 try {
		    String sql="select user_name from accounts_profile where reg_no=reg";
			
			PreparedStatement pt = con.prepareStatement(sql);
			ResultSet rs=pt.executeQuery();
			rs.next();
			//user=rs.getString(columnIndex)
			System.out.print(user);
			return user;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 return user;
	 
}
}