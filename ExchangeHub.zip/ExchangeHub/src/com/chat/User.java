package com.chat;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class User
 */
@WebServlet("/User")
public class User extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public User() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String to=request.getParameter("seller");
		//String to=request.getAttribute("seller").toString();
		response.setContentType("text/html");
		PrintWriter printWriter= response.getWriter();
		HttpSession httpSession= request.getSession(true);
		String username=request.getParameter("username");
		//String username=request.getAttribute("username").toString();
		httpSession.setAttribute("username", username);
		
		if(username!=null)
		{
			printWriter.println("<html>");
			printWriter.println("<head><title>chat</title>");
			printWriter.println("<script language=\"javascript\">");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("WEB-INF/js/websocket.js");
			requestDispatcher.include(request, response);
			printWriter.println("</script>");
			printWriter.println("</head>");
			printWriter.println("<body>");
			printWriter.println("<p id=\"from\">"+username+"</p>");
			printWriter.println("<p id=\"to\">"+to+"</p>");
			printWriter.println("<textarea id=\"messageTextArea\" readonly=\"readonly\" rows=\"10\" cols=\"45\"></textarea>");
			printWriter.println("<br/>");
			printWriter.println("<input type=\"text\" id=\"messageText\">");
			printWriter.println("<input type=\"button\" value=\"send\" onclick=\"sendMessage()\">");
			printWriter.println("<br/>");
			printWriter.println("<p id=\"status\"></p>");
			printWriter.println("</body>");
			printWriter.println("</html>");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
