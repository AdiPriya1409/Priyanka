/**
 * 
 */

var websocket = new WebSocket("ws://localhost:8082/ExchangeHub/chatApp");
websocket.onmessage = function processMessage(message) {
	var jsonData = JSON.parse(message.data);
	if (jsonData.message != null) {
		action = extractAction(jsonData.message);
		if (action == "CHAT") {
			from = extractFrom(jsonData.message);
			to = extractTo(jsonData.message);
			extractedMessage = extractMessage(jsonData.message);
			document.getElementById("messageTextArea").value += from+": "+extractedMessage
					+ "\n";
		} else {
			document.getElementById("status").innerHTML += jsonData.message
					+ "\n";
		}
	}
}
function sendMessage() {
	from = document.getElementById("from").innerHTML;
	to = document.getElementById("to").innerHTML;
	action = "ACTION~CHAT|FROM~" + from + "|TO~" + to + "|MSG~";
	message = document.getElementById("messageText").value;
	messageToSend = action + message;
	websocket.send(messageToSend);
	document.getElementById("messageText").value = "";
	document.getElementById("messageTextArea").value += "Me" + ": " + message
			+ "\n";
}
function extractFrom(message) {
	words = message.split('|')[1];
	from = words.split('~')[1];
	return from;
}
function extractTo(message) {
	words = message.split('|')[2];
	to = words.split('~')[1];
	return to;
}
function extractMessage(message) {
	words = message.split('|')[3];
	message = words.split('~')[1];
	return message;
}
function extractAction(message) {
	words = message.split('|')[0];
	action = words.split('~')[1];
	return action;
}